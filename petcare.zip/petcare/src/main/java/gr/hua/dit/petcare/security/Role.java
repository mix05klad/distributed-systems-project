package gr.hua.dit.petcare.security;

public enum Role {
    OWNER,
    VET,
    ADMIN //added for debugging
}
