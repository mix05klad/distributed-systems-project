package gr.hua.dit.petcare.core.model;

public enum PetType {
    DOG, CAT, BIRD, OTHER
}
